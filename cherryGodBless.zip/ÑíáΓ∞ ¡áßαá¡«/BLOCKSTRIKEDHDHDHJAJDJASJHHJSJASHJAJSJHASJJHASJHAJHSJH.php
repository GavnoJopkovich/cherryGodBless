<?php
require_once('DB.php');

function generateRandomToken($username, $owner) {
    // Generate a random token consisting of letters and numbers
    $token = substr(str_shuffle(str_repeat($x='ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890', ceil(10/strlen($x)))), 1, 10);
    return $owner . $username . $token; // Append the owner value to the token
}

$hours = 1;
$keys = 1;
$type = 'BLOCK';
$owner = 'FREE';

$ASS57767676 = 'BLOCK56665';

$db = new DB();
$conn = $db->getConnection();

// Check if the user has already created a key in the last hour
if (!isset($_COOKIE[$ASS57767676]) || (time() - (int)$_COOKIE[$ASS57767676]) >= 3600) {
    $token = generateRandomToken($type, $owner);
    $expiry = $hours * 3600;

    // Escape the data before inserting into the query
    $escaped_token = $conn->real_escape_string($token);
    $escaped_type = $conn->real_escape_string($type);
    $escaped_owner = $conn->real_escape_string($owner);
    $escaped_expiry = intval($expiry); // Convert to integer

    // Insert the token into the database
    $query = "INSERT INTO key_store (`id`, `key`, `link`, `user`, `type`, `one_time`, `freez`, `long`, `start_time`, `end_time`, `freez_time`) VALUES " .
        "(NULL, '$escaped_token', 0, 0, '$escaped_type', 0, 0, $escaped_expiry, 0, 0, 0)";
    if ($conn->query($query) !== TRUE) {
        echo "Error: " . $conn->error;
    } else {
        // Set the cookie with the current time
        setcookie($ASS57767676, time(), time() + 3600, '/'); // expires in 1 hour

        // Generate a random number and create the text file
        $randomNumber = rand(100000, 999999);
        $filename = "KEYS/BLOCK_{$randomNumber}.txt";
        $file = fopen($filename, 'w');
        fwrite($file, "Ваш ключ на 1 час - {$token}");
        fclose($file);
    }

        echo "<script>setTimeout(function() { window.location.href='https://cherry.gdupes.ru/Cherry/FREEMODS/" . $filename . "'; }, 1);</script>";
    } else {
        echo "<script>setTimeout(function() { window.location.href='https://cherry.gdupes.ru/Cherry/FREEMODS/LIMIT.php'; }, 1);</script>";
    }

?>