<?php
class DB {
    private $host = "localhost"; // Имя хоста
    private $username = "u2661436_cherry"; // Имя пользователя базы данных
    private $password = "jL6wN3rE7qaE8aI8"; // Пароль базы данных
    private $database = "u2661436_login"; // Имя базы данных
    
    public function getConnection() {
        $conn = new mysqli($this->host, $this->username, $this->password, $this->database);
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        return $conn;
    }
}
?>